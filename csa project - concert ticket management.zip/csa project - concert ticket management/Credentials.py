def get_creds():
    return "Enter Your Mysql Password"